/* ============================================================
   Pro Office – shared.js
   Wird von allen Seiten geladen. Kümmert sich um:
   1. Avatar-Initialen (JS → "JS")
   2. Auswertung-Link aktiv setzen
   3. Rechnungs-Pill dynamisch aus localStorage
   4. Logo-Persistenz via localStorage (LOGO_KEY)
   ============================================================ */

const LOGO_KEY   = 'prooffice_logo';
const DRAFT_KEY  = 'prooffice_rechnung_draft';
const RECH_KEY   = 'prooffice_rechnungen';
const EINSTELL_KEY = 'prooffice_einstellungen';

/* ── 1. Avatar ── */
function initAvatar() {
  document.querySelectorAll('.av').forEach(el => {
    if (el.getAttribute('aria-hidden') === 'true') el.textContent = 'JS';
  });
}

/* ── 2. Auswertung-Link ── */
function initNavLinks() {
  document.querySelectorAll('a.nav-link').forEach(a => {
    if (!a.href && a.textContent.includes('Auswertung')) {
      a.href = 'auswertung.html';
    }
  });
}

/* ── 3. Pill dynamisch ── */
function updatePill() {
  try {
    const rechnungen = JSON.parse(localStorage.getItem(RECH_KEY)) || [];
    const offenCount = rechnungen.filter(r => r.status === 'offen').length;
    document.querySelectorAll('.pill').forEach(p => {
      if (p.closest('.nav-link') && p.closest('.nav-link').href &&
          p.closest('.nav-link').href.includes('rechnungen')) {
        p.textContent = offenCount;
        p.style.display = offenCount === 0 ? 'none' : '';
      }
    });
  } catch(e) {}
}

/* ── 4. Logo-Persistenz ── */
function saveLogo(dataURL) {
  try { localStorage.setItem(LOGO_KEY, dataURL); } catch(e) {}
}
function loadLogo() {
  try { return localStorage.getItem(LOGO_KEY) || null; } catch(e) { return null; }
}
function clearLogo() {
  try { localStorage.removeItem(LOGO_KEY); } catch(e) {}
}

/* ── Init ── */
document.addEventListener('DOMContentLoaded', () => {
  initAvatar();
  initNavLinks();
  updatePill();
});
